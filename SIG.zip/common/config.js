var config = {};

config.mysql = {};

config.mysql.url = 'aatw9b7fxs9n02.cu131dmzk4oa.us-west-2.rds.amazonaws.com';
config.mysql.port = 3306;
config.mysql.dbName = 'ebdb';
config.mysql.userName = 'ronyherdiyanto';
config.mysql.password = 'ronelits131081';

module.exports = config;